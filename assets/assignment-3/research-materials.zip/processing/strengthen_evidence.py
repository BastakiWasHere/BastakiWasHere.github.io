"""Recompute exploratory spatial results and package a dated schema demonstration."""
import csv, json, statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ASSETS = ROOT.parent if (ROOT.parent/'chicago-school-programs-1921.json').exists() else ROOT.parent/'site-assignment-3/assets/assignment-3'
rows = json.loads((ASSETS / 'chicago-school-programs-1921.json').read_text())
headings = {r['institution_id']: r for r in rows if r['latitude'] is not None}
cut = statistics.median(r['latitude'] for r in headings.values())
summary, membership = [], []
for north in (False, True):
    label = 'Northern half' if north else 'Southern half'
    ids = {key for key, r in headings.items() if (r['latitude'] >= cut) == north}
    hs = [r for r in rows if r['institution_id'] in ids and r['program'] == 'Parochial high school']
    known = [r for r in hs if r['boys'] is not None and r['girls'] is not None]
    girls, boys = sum(r['girls'] for r in known), sum(r['boys'] for r in known)
    total = sum(r['students_total'] for r in hs)
    summary.append(dict(half=label, institution_headings=len(ids), high_school_subentries=len(hs),
                        classified_subentries=len(known), girls=girls, boys=boys,
                        unclassified_pupils=total-girls-boys,
                        girls_share_known_pct=round(100*girls/(girls+boys), 1),
                        girls_share_lower_pct=round(100*girls/total, 1),
                        girls_share_upper_pct=round(100*(total-boys)/total, 1),
                        dividing_latitude=cut))
    for r in hs:
        membership.append({k:r[k] for k in ('record_id','institution_id','institution_name','latitude','longitude','students_total','boys','girls','source_url')} | {'half':label})
for filename, data in [('spatial-comparison.csv',summary), ('spatial-membership.csv',membership)]:
    with (ASSETS/filename).open('w', newline='') as f:
        writer=csv.DictWriter(f, fieldnames=list(data[0]));writer.writeheader();writer.writerows(data)
assert [s['high_school_subentries'] for s in summary] == [11,17]
assert [s['girls_share_known_pct'] for s in summary] == [88.6,56.6]
assert sum(s['unclassified_pupils'] for s in summary)==139

# This demonstration is recorded after the dataset was built. It is not an
# original extraction transcript, a separate API run, or an accuracy benchmark.
demo = {
    'recorded_on':'2026-11-23', 'agent':'Codex',
    'status':'Post-build schema demonstration, visually read from the linked crop during review; not a transcript of the original extraction.',
    'source_page':95,
    'source_url':'https://archive.org/details/DirectoryCatholicCollegesSchools1921/page/n104/mode/1up',
    'image':'benedict-correction.jpg',
    'pass_1':{
        'instruction':'Read the St. Benedict school scan. Return one row per bold institution heading with institution, main enrollment total, boys, girls, and page. Omit personal staff names. Use the image, not the OCR.',
        'returned_rows':[{'institution':"St. Benedict’s School",'main_total':575,'boys':287,'girls':288,'page':95}]},
    'pass_2':{
        'instruction':'Refine the schema: return a separate row for every explicitly reported educational program, including indented subentries. Keep the institution link. Distinguish student enrollments from graduates. Never infer pupil sex from the institution name. Mark a zero as structural only when an explicit Total, Girls/Boys statement supports it. Omit personal staff names.',
        'returned_rows':[
            {'institution':"St. Benedict’s School",'program':'Elementary','students_total':575,'boys':287,'girls':288,'page':95},
            {'institution':"St. Benedict’s School",'program':'Parochial high school','students_total':27,'boys':0,'girls':27,'page':95,'note':'Boys=0 is a structural zero from the explicit girls-only total; 13 graduates are a different measure.'}]},
    'interpretation':'Both outputs read the image correctly within their schemas. The one-row schema hides the 27-pupil high-school subentry. The refined schema recovers the relationship. No artificial model error or independent human validation is claimed.'
}
(ASSETS/'extraction-demonstration.json').write_text(json.dumps(demo,ensure_ascii=False,indent=2)+'\n')

check_ids = ['CHI-010-2','CHI-014-1','CHI-026-1','CHI-026-2','CHI-041-2','CHI-059-2','CHI-009-2','CHI-158-2','CHI-184-2','CHI-185-1']
worksheet=[]
for rid in check_ids:
    r=next(r for r in rows if r['record_id']==rid)
    worksheet.append({k:r[k] for k in ('record_id','institution_name','program','students_total','boys','girls','page','source_url')} | {'human_reviewer':'','checked_on':'','matches_scan':'','reviewer_notes':''})
with (ASSETS/'human-review-worksheet.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(worksheet[0]));w.writeheader();w.writerows(worksheet)

for name in ['strengthen_evidence.py']:
    import shutil
    destination=ASSETS/'processing'/name
    if (ROOT/name).resolve() != destination.resolve():
        shutil.copy2(ROOT/name,destination)
print('Spatial comparison verified; schema demonstration and blank human-review worksheet generated.')
