import json,re,csv,collections
from pathlib import Path
from scan_review import MAIN,HIGH,NAME_FIXES,ADDRESS_FIXES
R=Path(__file__).parent
parents=json.load(open(R/'parents-initial.json'));rows=json.load(open(R/'programs-initial.json'))
changes=[]
for page,values in MAIN.items():
    values=[[None if v=='-' else int(v) for v in x.split()] for x in values.split(';')]
    pp=[x for x in parents if x['page']==page]
    assert len(values)==len(pp),(page,len(values),len(pp))
    for p,vs in zip(pp,values):
        row=next(x for x in rows if x['institution_id']==p['institution_id'] and x['classification_basis']=='Printed entry')
        for field,v in zip(['students_total','boys','girls'],vs):
            if row[field]!=v: changes.append(dict(record_id=row['record_id'],page=page,field=field,ocr=row[field],reviewed=v,basis='Visual comparison with printed scan'))
            row[field]=v

for r in rows:
    n=int(r['institution_id'].split('-')[1])
    r['institution_name_ocr']=r['institution_name']
    name=NAME_FIXES.get(n,r['institution_name'])
    name=name.replace('’',"'").replace('‘',"'")
    name=re.sub(r'^ST[ ,.-]*\s*','ST. ',name)
    # Title case affects presentation only. Preserve acronyms in original column.
    r['institution_name']=re.sub(r"'S\b", "'s", name.title().replace('Ss.','SS.'))
    addr=ADDRESS_FIXES.get(n,r['address_original'])
    addr=re.split(r'\s+(?:Con\w*|Cou\w*|Ck\)nducted|\(’onducted|t’onducted)\s+by\b',addr)[0]
    r['address_transcribed']=addr
    if n in HIGH and r['program']=='Parochial high school':
        for k,v in zip(['students_total','boys','girls'],HIGH[n]):
            if r[k]!=v:changes.append(dict(record_id=r['record_id'],page=r['page'],field=k,ocr=r[k],reviewed=v,basis='Visual comparison with printed scan; combine distinct H.S. and Comm. H.S. subtotals only at CHI-158'))
            r[k]=v
    r['value_status']='Scan reviewed by Codex; not independently human-validated'
    r['review_note']=''
    r['program_detail']='Commercial high school' if 'Comm. H. S.' in r['enrollment_evidence'] and r['program']=='Parochial high school' else r['program']
    if r['program']=='Parochial high school' and n in [9,131,157]:
        r['review_note']='Subentry follows a girls-school heading but explicitly reports boys or both sexes. Linked to the shared address; heading does not determine pupil sex.'
        r['institution_name']=r['institution_name'].replace(" Girls'",'')+' (shared high-school subentry)'
    if r['program']=='Parochial high school' and n==158:
        r['program_detail']='High school + commercial high school'
        r['review_note']='Combined the two explicitly separate student subtotals: H.S. 81 (37 boys, 44 girls) + Comm. H.S. 15 (2 boys, 13 girls). Not a duplicated institution.'
    if n==158 and r['program']=='Elementary':
        r['classification_basis']='Inferred from Grades, 8 and separate high-school subentry; heading omits Elem.'
        r['review_note']='Main entry says Par. H.S. but reports Grades, 8, then a separate high-school subtotal. Elementary classification is interpretive.'
    if n==132:r['review_note']='Heading says Kind. but also prints Grades, 8. Classified by explicit Kind. label; discrepancy retained.'
    if n==20:r['review_note']='Institution name is partly obscured in scan; Assumption is a qualified reading.'
    if r['students_total'] is None:r['review_note']='Enrollment not printed in the selected entry. Blank is not zero.'
    r['arithmetic_status']='Sex breakdown not printed' if r['boys'] is None or r['girls'] is None else 'Agrees' if r['students_total']==r['boys']+r['girls'] else 'Printed discrepancy'
    if r['arithmetic_status']=='Printed discrepancy':
        r['review_note']+=' Printed total and boys + girls disagree. Preserved rather than silently repaired.'

(R/'programs-reviewed.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False))
(R/'numeric-corrections.json').write_text(json.dumps(changes,indent=2,ensure_ascii=False))
# New geocoding request after scan corrections, with reproducible spelling normalization.
queries=[]
for p in parents:
    r=next(x for x in rows if x['institution_id']==p['institution_id'])
    a=r['address_transcribed'].replace('pi.','pl.').replace(' pi',' pl').replace('Sunnyslde','Sunnyside').replace('Glen wood','Glenwood')
    a=re.sub(r'\b(\d*[23])d\b',r'\1nd' if False else lambda m:m[1]+('nd' if m[1].endswith('2') else 'rd'),a)
    if re.match(r'^\d+\s+',a) and not any(w in a for w in ['22-7','36r','3C19']):queries.append([p['institution_id'],a,'Chicago','IL',''])
with open(R/'census-reviewed-input.csv','w') as f:csv.writer(f).writerows(queries)
print('rows',len(rows),'headings',len(parents),'numeric field corrections',len(changes))
print(collections.Counter(x['arithmetic_status'] for x in rows))
for p in ['Elementary','Parochial high school','Kindergarten']:
    rr=[x for x in rows if x['program']==p];known=[x for x in rr if x['boys'] is not None and x['girls'] is not None]
    print(p,len(rr),'total',sum(x['students_total'] or 0 for x in rr),'boys/girls',sum(x['boys'] for x in known),sum(x['girls'] for x in known),'sex_known_rows',len(known))
