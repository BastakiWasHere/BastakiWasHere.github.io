"""Match named road pairs to shared nodes in Chicago's street-centerline data.
Street directions and type expansions are query assumptions; not historical proof.
"""
import json,urllib.parse,subprocess,re,math
from pathlib import Path
from street_pairs import PAIRS
R=Path(__file__).parent
def parts(name):
    words=name.upper().split();direction={'NORTH':'N','SOUTH':'S','EAST':'E','WEST':'W'}[words.pop(0)]
    typ={'STREET':'ST','AVENUE':'AVE','BOULEVARD':'BLVD','ROAD':'RD','PLACE':'PL'}[words.pop()]
    return direction,' '.join(words),typ

if __name__=='__main__':
    names=sorted(set(parts(n)[1] for pair in PAIRS.values() for n in pair))
    params={'$limit':15000,'$select':'fnode_id,tnode_id,the_geom,pre_dir,street_nam,street_typ',
            '$where':'street_nam in ('+','.join("'"+n+"'" for n in names)+')'}
    url='https://data.cityofchicago.org/resource/pr57-gg9e.json?'+urllib.parse.urlencode(params)
    (R/'city-query-url.txt').write_text(url)
    cache=R/'city-streets.json'
    if not cache.exists():subprocess.run(['curl','-fLsS','--max-time','120',url,'-o',str(cache)],check=True)
    roads=json.load(open(cache));assert len(roads)<15000,'Query limit reached'
    byname={}
    for road in roads:
        key=(road.get('pre_dir',''),road['street_nam'],road.get('street_typ',''))
        points=road['the_geom']['coordinates']
        coords=[points[0][0],points[-1][-1]]
        d=byname.setdefault(key,{})
        for node,coord in zip([road['fnode_id'],road['tnode_id']],coords):d[node]=coord
    results={}
    for n,(a,b) in PAIRS.items():
        aa=byname.get(parts(a),{});bb=byname.get(parts(b),{});nodes=sorted(set(aa)&set(bb))
        if not nodes:print(n,'UNRESOLVED',a,b);continue
        points=[aa[node] for node in nodes]
        lon=sum(p[0] for p in points)/len(points);lat=sum(p[1] for p in points)/len(points)
        spread=max(math.hypot((p[1]-lat)*111000,(p[0]-lon)*83000) for p in points)
        if spread>150:print(n,'AMBIGUOUS');continue
        results[f'CHI-{n:03d}']=dict(latitude=round(lat,5),longitude=round(lon,5),
            geocode_method='City street-intersection reference',matched_address=a+' & '+b,
            street_nodes=nodes,geocode_source='https://data.cityofchicago.org/resource/pr57-gg9e.json',
            location_note='Modern street-centerline intersection, not a verified 1921 campus. Street directions/types expanded as query assumptions. Source: City of Chicago, pr57-gg9e; retrieved 2026-11-23.')
        print(n,round(lat,5),round(lon,5))
    (R/'intersections-results.json').write_text(json.dumps(results,indent=2))
    print('Resolved',len(results),'of',len(PAIRS),'institution references; roads retrieved',len(roads))
