import json,csv,re,collections,statistics,shutil
from pathlib import Path
R=Path(__file__).parent
SITE=R.parent/'site-assignment-3'
OUT=SITE/'assets'/'assignment-3';OUT.mkdir(parents=True,exist_ok=True)
rows=json.load(open(R/'programs-reviewed.json'));initial={r['record_id']:r for r in json.load(open(R/'programs-initial.json'))}
parents={p['institution_id']:p for p in json.load(open(R/'parents-initial.json'))}
census={r[0]:r for r in csv.reader(open(R/'census-reviewed-results.csv'))}
intersections=json.load(open(R/'intersections-results.json'))
queries={r[0]:r[1] for r in csv.reader(open(R/'census-reviewed-input.csv'))}
for r in rows:
    pid=r['institution_id'];p=parents[pid];c=census.get(pid)
    r['offered_program_codes_ocr']=p['codes_ocr']
    if pid=='CHI-058':
        # A broken OCR parenthesis overruns the abbreviation into staff text.
        # Keep the damaged abbreviation but exclude the personal-name spillover.
        r['offered_program_codes_ocr']='Elem. L [damaged closing bracket]'
    r['latitude']=None;r['longitude']=None;r['matched_address']='';r['geocode_source']='';r['geocode_query']=c[1] if c else ''
    r['geocode_status']='Unmapped';r['geocode_method']='Unresolved'
    r['location_note']='No defensible coordinate assigned. This is missing location evidence, not evidence of school absence.'
    if c and c[2]=='Match':
        lon,lat=map(float,c[5].split(','))
        assert 41.60<lat<42.04 and -87.88<lon<-87.51,(pid,lat,lon)
        r.update(latitude=round(lat,5),longitude=round(lon,5),matched_address=c[4],
          geocode_status='Modern address reference',geocode_method='US Census Public_AR_Current ('+c[3]+')',
          geocode_source='https://geocoding.geo.census.gov/geocoder/Geocoding_Services_API.html',
          location_note='Modern address-range interpolation, not a verified 1921 campus. A successful match does not validate historical street continuity. Missing directions may have been supplied by the geocoder.')
    elif pid in intersections:
        r.update(intersections[pid]);r['geocode_status']='Modern intersection reference'
        r['geocode_query']=r['matched_address']
    else:
        a=r['address_transcribed']
        reason='No street address printed' if not a else 'Unresolved street number in scan' if '22-7' in a else 'Street or incomplete address only' if not re.match(r'^\d+\s+',a) else 'Ambiguous modern address match' if c and c[2]=='Tie' else 'No modern address match'
        r['geocode_method']=reason
    raw=initial[r['record_id']]
    r['students_total_ocr']=raw['students_total'];r['boys_ocr']=raw['boys'];r['girls_ocr']=raw['girls']
    r['retrieved_on']='2026-11-23';r['crs']='EPSG:4326'
    if 'street_nodes' in r:r['street_nodes']=';'.join(r['street_nodes'])
    else:r['street_nodes']=''

assert len(rows)==235 and len({r['institution_id'] for r in rows})==200
assert len({r['record_id'] for r in rows})==len(rows)
assert all(r['page'] in range(92,111) for r in rows)
assert all((r['latitude'] is None)==(r['longitude'] is None) for r in rows)
assert all(r['students_total'] is None or r['students_total']>=0 for r in rows)
fields=['record_id','institution_id','institution_name','institution_name_ocr','program','program_detail','offered_program_codes_ocr','address_original','address_transcribed','city','state','year','students_total','boys','girls','students_total_ocr','boys_ocr','girls_ocr','enrollment_evidence','arithmetic_status','classification_basis','review_note','value_status','latitude','longitude','crs','geocode_status','geocode_method','geocode_query','matched_address','geocode_source','location_note','street_nodes','page','source_leaf','source_url','retrieved_on']
with open(OUT/'chicago-school-programs-1921.csv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
(OUT/'chicago-school-programs-1921.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
features=[{'type':'Feature','geometry':{'type':'Point','coordinates':[r['longitude'],r['latitude']]} if r['latitude'] is not None else None,'properties':{k:v for k,v in r.items() if k not in ['latitude','longitude']}} for r in rows]
(OUT/'chicago-school-programs-1921.geojson').write_text(json.dumps({'type':'FeatureCollection','features':features},ensure_ascii=False))
changes=json.load(open(R/'numeric-corrections.json'))
with open(OUT/'numeric-corrections.csv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=['record_id','page','field','ocr','reviewed','basis']);w.writeheader();w.writerows(changes)
descriptions={
'record_id':'Unique reporting-unit identifier. Not a person or campus identifier.',
'institution_id':'Printed institution heading identifier, CHI-001 through CHI-200. Repeated across subentries.',
'institution_name':'Readable institution label; qualified readings identified. Shared high-school labels do not inherit sex from a girls-school heading.',
'institution_name_ocr':'Initial OCR institution heading, retained for provenance.',
'program':'Elementary / Parochial high school / Kindergarten. Printed subentries and main entries are reporting units, not necessarily distinct buildings.',
'program_detail':'Commercial high-school label where explicitly stated. CHI-158-2 combines separately printed H.S. and Comm. H.S. student subtotals.',
'offered_program_codes_ocr':'Printed main-entry abbreviation string from OCR. At CHI-058, truncated before staff-name spillover caused by a broken bracket. A listed offering need not have a separate numeric subentry.',
'address_original':'Initial OCR address string before scan review. OCR errors may remain in this provenance field.',
'address_transcribed':'Scan-reviewed historical address. Do not treat it as a current institution address.',
'city':'Chicago heading in the source; not a claim that every point lies inside a modern boundary.',
'state':'IL (Illinois), USA.', 'year':'1921 directory publication year, not an independently verified enrollment census date.',
'students_total':'Printed total after scan review. Blank = not printed. Printed arithmetic disagreements are preserved.',
'boys':'Source category Boys. Zero is structurally derived where Total explicitly says Girls; blank = unreported, never inferred from school name.',
'girls':'Source category Girls. Zero is structurally derived where Total explicitly says Boys; blank = unreported, never inferred from school name.',
'students_total_ocr':'Initial automated extraction before visual corrections. Not the preferred analysis field.',
'boys_ocr':'Initial extracted boys count, not preferred analysis field.',
'girls_ocr':'Initial extracted girls count, not preferred analysis field.',
'enrollment_evidence':'Initial OCR student passage, excluding staff names. It may differ from the reviewed numeric fields.',
'arithmetic_status':'Agrees / Sex breakdown not printed / Printed discrepancy. Arithmetic agreement is not independent validation.',
'classification_basis':'Printed entry or subheading; explicit note for the inferred elementary classification at CHI-158-1.',
'review_note':'Source ambiguities, interpretation decisions and preserved inconsistencies.',
'value_status':'Review performed by Codex against selected scans. No independent human validation is claimed.',
'latitude':'WGS84 latitude of a modern reference, rounded to 5 decimals. Blank when unresolved; digits do not imply historical accuracy.',
'longitude':'WGS84 longitude of a modern reference, rounded to 5 decimals. Blank when unresolved.',
'crs':'EPSG:4326; GeoJSON writes longitude before latitude.',
'geocode_status':'Modern address reference / Modern intersection reference / Unmapped. None proves a historical campus parcel.',
'geocode_method':'Census address match type, city road-node intersection, or reason for unresolved location.',
'geocode_query':'Exact normalized modern address query, or expanded contemporary street pair. Expansions are assumptions.',
'matched_address':'Modern geocoder-returned address or selected street intersection. Preserve separately from historical address.',
'geocode_source':'Provider documentation or City of Chicago street-centerline endpoint.',
'location_note':'Limits of location evidence and modern versus historical interpretation.',
'street_nodes':'Semicolon-separated shared city road-network node IDs for intersection references; blank otherwise.',
'page':'Printed page number, 92–110, Chicago city subsection only.',
'source_leaf':'Internet Archive scan leaf / URL n-number. This is not the printed page number.',
'source_url':'Direct link to the original scanned page.',
'retrieved_on':'ISO-format retrieval and processing date.'}
with open(OUT/'data-dictionary.csv','w',newline='') as f:
    w=csv.writer(f);w.writerow(['field','meaning']);w.writerows((k,descriptions[k]) for k in fields)
hs=[r for r in rows if r['program']=='Parochial high school'];known=[r for r in hs if r['boys'] is not None and r['girls'] is not None]
stats={'records':len(rows),'headings':200,'program_counts':dict(collections.Counter(r['program'] for r in rows)),
 'mapped_records':sum(r['latitude'] is not None for r in rows),
 'mapped_headings':len({r['institution_id'] for r in rows if r['latitude'] is not None}),
 'locations':len({(r['latitude'],r['longitude']) for r in rows if r['latitude'] is not None}),
 'location_status':dict(collections.Counter(r['geocode_status'] for r in rows)),
 'hs_total':sum(r['students_total'] for r in hs),'hs_known_total':sum(r['boys']+r['girls'] for r in known),
 'hs_girls':sum(r['girls'] for r in known),'hs_boys':sum(r['boys'] for r in known),
 'hs_unknown_sex':sum(r['students_total'] for r in hs if r['boys'] is None or r['girls'] is None),
 'hs_girls_majority':sum(r['girls']>r['boys'] for r in known),
 'hs_boys_majority':sum(r['girls']<r['boys'] for r in known),
 'hs_equal':sum(r['girls']==r['boys'] for r in known),
 'hs_small':sum(r['students_total']<=33 for r in hs),'numeric_field_changes':len(changes),
 'printed_discrepancies':[r['record_id'] for r in rows if r['arithmetic_status']=='Printed discrepancy'],
 'hs_median':statistics.median(r['students_total'] for r in hs)}
(OUT/'summary-statistics.json').write_text(json.dumps(stats,indent=2))
print(json.dumps(stats,indent=2))
