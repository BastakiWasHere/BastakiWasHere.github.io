"""Source-specific extraction authored with Codex; no external LLM API calls.
Unit: a printed program at an institution, not a student or a building.
All source strings retained privately; public output excludes staff names.
"""
import re, json, csv
from pathlib import Path
ROOT=Path(__file__).parent

def clean(s):
    s=re.sub(r'(\w)-\s*\n\s*(\w)',r'\1\2',s)
    return re.sub(r'\s+',' ',s).strip()

def num(s):
    return int(re.sub(r'[, .]','',s)) if s else None

def enrollment(s):
    s=clean(s)
    m=re.search(r'Students?\s*[—–^\-]*\s*Total[.,:]?\s*(.*?)(?=Graduates|Grades|$)',s,re.I)
    if not m: return None,None,None,''
    e=m[1]
    first=re.search(r'\d[\d,]*(?:\.\d{3})?',e)
    total=num(first[0]) if first else None
    boys=re.search(r'(?:Boys|Bbys|Bo3rs)[.,:]?\s*([\d][\d,.]*)',e,re.I)
    girls=re.search(r'(?:Girls|Glrls|oIrls|uiris|o irls|o irIs)[.,:]?\s*([\d][\d,.]*)',e,re.I)
    b=num(boys[1].rstrip('.,')) if boys else None
    g=num(girls[1].rstrip('.,')) if girls else None
    # A source explicitly saying "Total, Boys, 240" supplies a one-sex total.
    before=e[:first.start()] if first else ''
    if re.search(r'Boys',before,re.I) and not girls: b=total;g=0
    if re.search(r'Girls',before,re.I) and not boys: g=total;b=0
    return total,b,g,'Students—Total, '+e.strip()

parents=[];programs=[]
header=re.compile(r'(?m)^([^\n]{3,100}?(?:\n[^\n]{3,100}?)?)\s*\((?=(?:Elem|Elera|Ehm|Elen|Kind|Par\.))')
for page in range(92,111):
    s=(ROOT/'source'/f'page-{page}.txt').read_text()
    if page==110:s=s.split('ARGO.')[0]
    # OCR gives these two bracket defects. Preserve the original block below.
    matches=list(header.finditer(s))
    for k,m in enumerate(matches):
        name=clean(m[1]);name=name.lstrip('(')
        if name in ['CHICAGO.','ELEMENTARY AND PAROCHIAL HIGH SCHOOLS.']:continue
        block=s[m.start():matches[k+1].start() if k+1<len(matches) else len(s)]
        block=clean(block)
        name=clean(m[1]);pos=block.find('(')
        # Name-internal OCR parentheses need to remain attached to the name.
        marker=re.search(r'\((?:Elem|Elera|Ehm|Elen|Kind|Par\.)',block)
        after=block[marker.start():] if marker else ''
        close=after.find(')')
        codes=after[1:close] if 0<=close<65 else after[1:after.find(',')]
        after=after[close+1:] if 0<=close<65 else re.sub(r'^\([^,]+,','',after)
        addr=re.split(r'(?:Conducted|Con[- ]?ducted|C[ou]nducted|Condiict|Condnct|Conact|Con-)',after,1)[0].strip(' .,')
        # In malformed OCR "(Elem. L" the address begins after L.
        addr=re.sub(r'^\(?(?:Elem\.?\s*[L)]?|Ehm\.?)\s*','',addr).strip(' .,')
        # Never copy personal details into an address field.
        addr=re.split(r'\b(?:Rev|Rt|Sr|Teachers|Students|Mother)\b',addr)[0].strip(' .,')
        pid=f'CHI-{len(parents)+1:03d}'
        parent=dict(institution_id=pid,institution_name_ocr=name,page=page,
          source_leaf=page+9,source_url=f'https://archive.org/details/DirectoryCatholicCollegesSchools1921/page/n{page+9}/mode/1up',
          address_ocr=addr,codes_ocr=codes,block=block)
        parents.append(parent)
        sections=re.split(r'(?=Parochial (?:Hig[rh]+|High) School|Kindergarten\.)',block)
        for j,sec in enumerate(sections):
            if not sec.strip():continue
            level='Kindergarten' if sec.startswith('Kindergarten') or (j==0 and codes.startswith('Kind')) else 'Parochial high school' if sec.startswith('Parochial') else 'Elementary'
            total,b,g,ev=enrollment(sec)
            row=dict(record_id=f'{pid}-{j+1}',institution_id=pid,institution_name=name,
                program=level,address_original=addr,city='Chicago',state='IL',year=1921,
                students_total=total,boys=b,girls=g,enrollment_evidence=ev,
                page=page,source_leaf=page+9,source_url=parent['source_url'],
                classification_basis='Printed subheading' if j else 'Printed entry',
                review_note='',value_status='Unverified OCR')
            if total is not None and b is not None and g is not None and b+g!=total:
                row['review_note']='OCR total differs from boys + girls; retain discrepancy pending scan review'
            programs.append(row)

(ROOT/'parents-initial.json').write_text(json.dumps(parents,ensure_ascii=False,indent=2))
(ROOT/'programs-initial.json').write_text(json.dumps(programs,ensure_ascii=False,indent=2))
print('Institution headings:',len(parents),'Program rows:',len(programs))
from collections import Counter
print(Counter(r['program'] for r in programs))
for p in parents: print(p['institution_id'],p['page'],p['institution_name_ocr'],'|',p['address_ocr'])
print('\nFLAGS')
for r in programs:
    if r['review_note'] or r['students_total'] is None: print(r['record_id'],r['institution_name'],r['students_total'],r['boys'],r['girls'],r['review_note'])
