import json,re,csv
from pathlib import Path
R=Path(__file__).parent
p=json.load(open(R/'parents-initial.json'))
queries=[]
for x in p:
    a=x['address_ocr']
    a=re.split(r'\s+(?:Con\w*|Cou\w*|Ck\)nducted|\(’onducted|t’onducted)\s+by\b',a)[0]
    a=a.replace('pi.','pl.').replace(' pi',' pl').replace('Sunnyslde','Sunnyside').replace('LafUn','Laflin').replace('Glen wood','Glenwood')
    # Do not guess missing digits, directions, or historical street renamings.
    if not re.match(r'^\d+\s+',a) or any(w in a for w in ['22-7','36r','3C19']):continue
    queries.append([x['institution_id'],a,'Chicago','IL',''])
with open(R/'census-input.csv','w') as f:csv.writer(f).writerows(queries)
print('Numbered address queries:',len(queries))
