import csv,collections,statistics,json
from pathlib import Path
r=list(csv.DictReader(open(Path(__file__).resolve().parent.parent/"chicago-school-programs-1921.csv")))
assert len(r)==235 and len({x["institution_id"] for x in r})==200
assert len({x["record_id"] for x in r})==235
assert sum(bool(x["latitude"]) for x in r)==194
assert all(bool(x["latitude"])==bool(x["longitude"]) for x in r)
assert all(41.60<float(x["latitude"])<42.04 and -87.88<float(x["longitude"])<-87.51 for x in r if x["latitude"])
h=[x for x in r if x["program"]=="Parochial high school"]
k=[x for x in h if x["boys"]!="" and x["girls"]!=""]
assert len(h)==32 and len(k)==30
assert sum(int(x["students_total"]) for x in h)==2211
assert sum(int(x["girls"]) for x in k)==1439
assert sum(int(x["boys"]) for x in k)==633
assert sum(int(x["students_total"])<=33 for x in h)==15
assert {x["record_id"] for x in r if x["arithmetic_status"]=="Printed discrepancy"}=={"CHI-014-1","CHI-185-1"}
print("Verified: 235 reporting units, 200 headings, 194 mapped records; high-school girls share =",round(1439/2072*100,1))
